
import java.awt.Color;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author alexandre
 */
public class DisplayDigitalWindow extends JFrame {

    private DisplayDigital displayDigital;
    private int sleep = 100;
    private byte tamanhoDoDisplay = LedDisplay.MEDIUM;

    public DisplayDigitalWindow(int sleep, byte tamanhoDoDisplay) {

        if (sleep >= 0 && sleep <= Integer.MAX_VALUE) {
            this.sleep = sleep;
        }

        if (tamanhoDoDisplay >= 0) {
            this.tamanhoDoDisplay = tamanhoDoDisplay;
        }

    }

    public void configureAndShow() throws DisplayDigitalException {

        addWindowListener(new WindowAdapterImpl());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle(getClass().getSimpleName() + " App");

        getContentPane().setBackground(new Color(255, 255, 192));

        setResizable(false);

        setUndecorated(false);

        addMouseListener(new MouseAdapter() {//moves the frame to mouse released positions

            Point fromPosition = null;
            Point toPosition = null;

            @Override
            public void mousePressed(MouseEvent e) {
                super.mouseClicked(e);
                fromPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                toPosition = new Point(e.getXOnScreen(), e.getYOnScreen());
                setBounds(getBounds().x + (-fromPosition.x + toPosition.x), getBounds().y + (-fromPosition.y + toPosition.y), getWidth(), getHeight());
            }
        });

        placeComponentsAtFrame();

        pack();

        //centralizes the frame
        setBounds((Toolkit.getDefaultToolkit().getScreenSize().width - getWidth()) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2, getWidth(), getHeight());

        Color[] ledColors = {Color.WHITE, Color.GREEN, Color.DARK_GRAY, Color.BLUE, Color.ORANGE, Color.PINK, Color.RED, Color.YELLOW};

        Random bckColorRandom = new Random();
        Random ledColorColorRandom = new Random();

        new Thread(() -> {

            //testa setting de todos os valores possiveis q o display pode assumir
            for (int i = 0; i <= 99999; i++) {

                try {

                    Thread.currentThread().sleep(sleep);

                } catch (InterruptedException ex) {
                    Logger.getLogger(DisplayDigitalWindow.class.getName()).log(Level.SEVERE, null, ex);
                }

                if (i % 100 < 10) {

                    displayDigital.setValor(Float.parseFloat(i / 100 + ".0" + i % 100));

                } else {

                    displayDigital.setValor(Float.parseFloat(i / 100 + "." + i % 100));

                }

                
                
                if (i % 100 == 20 || i % 100 == 99) {

                    displayDigital.setLedColor(ledColors[ledColorColorRandom.nextInt(ledColors.length)]);

                    System.out.println("\n[INFO] : Display digital : cor do led mudada para " + displayDigital.getLedColor().toString() + ", em " + new Date());

                }

            }

            displayDigital.setLedColor(Color.WHITE);

            try {

                System.out.println("\n[INFO] : Display digital : TODOS VALORES POSSÍVEIS TESTADOS " + ", em " + new Date());

                System.out.println("\n[INFO] : Display digital : fechando em 3s");

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        displayDigital.setValor(3.00f);
                    }
                }).start();

                Thread.sleep(1000);

                System.out.println("\n[INFO] : Display digital : fechando em 2s");

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        displayDigital.setValor(2.00f);
                    }
                }).start();

                Thread.sleep(1000);

                System.out.println("\n[INFO] : Display digital : fechando em 1s");

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        displayDigital.setValor(1.00f);
                    }
                }).start();

                Thread.sleep(1000);

                exitForm(null);

            } catch (InterruptedException ex) {
                Logger.getLogger(DisplayDigitalWindow.class.getName()).log(Level.SEVERE, null, ex);
            }

        }).start();

        setVisible(true);

    }

    private void placeComponentsAtFrame() throws DisplayDigitalException {

        displayDigital = new DisplayDigital(tamanhoDoDisplay);

        tamanhoDoDisplay = displayDigital.getTamanho();

        getContentPane().add(displayDigital);

        displayDigital.setValor(9.99f);

        System.out.println("[INFO] : Display digital executando TESTE  com sleep=" + this.sleep + " e tamanhoDoDisplay=" + this.tamanhoDoDisplay + ", em " + new Date());

    }

    private void exitForm(WindowEvent evt) {
        System.exit(JFrame.NORMAL);
    }

    private class WindowAdapterImpl extends WindowAdapter {

        public WindowAdapterImpl() {
        }

        public void windowClosing(WindowEvent evt) {
            exitForm(evt);
        }
    }

    public static void main(String[] args) throws DisplayDigitalException {

        int sleep = -1;
        byte tamanhoDoDisplay = -1;

        try {
            sleep = Integer.parseInt(args[0]);
        } catch (Exception e) {
        }

        try {
            tamanhoDoDisplay = Byte.parseByte(args[1]);
        } catch (Exception e) {
        }

        new DisplayDigitalWindow(sleep, tamanhoDoDisplay).configureAndShow();
    }

}
